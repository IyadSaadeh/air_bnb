INSERT INTO `language` (`id`, `code`, `name`, `flag_code`, `flag_name`, `priority`, `status`, `created_at`, `updated_at`, `rtl`) VALUES
(1, 'ar', 'Arabia', 'sa', 'Saudi Arabia', 2, 'on', '2020-08-24 11:34:43', '2020-08-25 03:37:05', 'on'),
(2, 'en', 'English', 'gb', 'United Kingdom of Great Britain and Northern Ireland', 1, 'on', '2020-08-25 03:36:33', '2020-08-25 03:37:05', 'no');
