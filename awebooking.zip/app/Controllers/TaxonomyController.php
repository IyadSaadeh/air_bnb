<?php

namespace App\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Sentinel;

class TaxonomyController extends Controller
{


}
