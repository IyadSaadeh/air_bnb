'use strict';

(function ($) {

})(jQuery);
